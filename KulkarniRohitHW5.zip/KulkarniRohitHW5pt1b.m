clc; clear;
x = 0:0.005:2;
y = 17 * x - 20 * x .^ 2 + 6 * x .^ 3;
hold on
plot(x,y)
x_data= [0 0.5 1 2];
y_data= [0 4.25 3 2];
plot(x_data, y_data, 'o');
hold off


