close all; clear; clc;
AirTempData = load('SantaCruzAirTempMaxMin2015to2019.txt');

% delete the second column (time of measurement) since we don't need it
AirTempData(:,2) = []; 

% create the column vectors for max and min temperatures
MaxTemp = AirTempData(:,2); MinTemp = AirTempData(:,3);

%% plot now
figure(1)
years = 0:1:1825;
box on
hold on
plot(years,MaxTemp, 'b')
plot(years, MinTemp, 'b')
hold off

% type in the plotting and axis styling commands here
xtickangle(35)
xline(365, 'r', 'LineWidth', 2);
xline(731, 'r', 'LineWidth', 2);
xline(1096, 'r', 'LineWidth', 2);
xline(1461, 'r', 'LineWidth', 2);
xticks([0,365,731,1096,1461]);
xticklabels({'Jan 1,2015',  'Jan 1, 2016', 'Jan 1, 2017','Jan 1, 2018', 'Jan 1, 2019'});
ylabel("temperature in � F")
set(gcf, 'color', 'w');



axis tight
title('Maximum and minimum daily air temperatures in Santa Cruz, 2015-2019')
set(gca,'FontSize',16)