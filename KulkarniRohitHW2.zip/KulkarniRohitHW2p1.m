%Rohit Kulkarni
%HW2

%for 1<=n<=100 compute and plot the distinct positive
%integer solutions (x,y) versus n for 1/x + 1/y = 1/n
%1<=x, y<=5000

num_distinct_sol = [1, 100];

for n_vec = 1:1:100
    num_distinct_sol(n_vec) = 0;
    distinct_solns = zeros(5000);
    for x=1:1:5000
        for y=1:1:5000
            if (1/x + 1/y) == 1/n_vec && distinct_solns(y) ~= x
                num_distinct_sol(n_vec) = num_distinct_sol(n_vec) + 1;
                distinct_solns(x) = y;
            end
        end
    end
end

n_vec = 1:1:100;
plot(n_vec,num_distinct_sol,'-bo')
xlabel("n values");
ylabel("number of distinct solutions");

