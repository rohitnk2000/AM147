function c = bisection(a, b, func_x, tolerance, max_it)
%parse string func_x into function f( )    
f = str2func(func_x);
%checks to see if f(a) and f(b) are different signs
%to ensure that there is a zero in the interval
if f(a) * f(b) >= 0
    disp('Invalid Input')
    quit;
end
%loop only runs for max iterations before terminating
for i = 1:1:max_it
    %find the midpoint between the interval
    c = (a + b)/2;
    %if f(c) is close enough to 0, then break because the algorithm
    %has found an acceptable solution
    if abs(f(c)) < tolerance
        break;
    end
    %if f(c) and f(a) have the same sign, 
    %then set the a boundary to c
    if f(c) * f(a) >= 0
        a = c;
    else
        %otherwise, if f(c) and f(b) have the same sign,
        %then set the b boundary to c
        if f(c) * f(b) >= 0
            b = c;
        end
    end     
end
end