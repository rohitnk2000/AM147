%calculate error for using formula(i) to estimate exp(-5)
estimation_1 = 0;
for j = 0:1:9
    estimation_1 = estimation_1 + ((-5)^j)/(factorial(j));
end
%error_1 stores the calculated error for first error
error_1 = abs(exp(-5) - estimation_1);
error_1 = error_1/exp(-5);

%calculate error for using formula(ii) to estimate exp(-5)
%by calculating 1/(exp(5))
estimation_2 = 0;
for i = 0:1:9
    estimation_2 = estimation_2 + (5^j)/(factorial(j));
end
%because we are calculating 1/exp(5) for the formula
estimation_2 = 1 / estimation_2;
error_2 = abs(exp(-5) - estimation_2);
error_2 = error_2/exp(-5);

disp('True Value: ')
disp(exp(-5))
disp('Value obtained from formula(i) ')
disp(estimation_1)
disp('Relative error in using formula(i) is ')
disp(error_1)
disp('Value obtained from formula(ii) ')
disp(estimation_2)
disp('Relative error in using formula(ii) is ')
disp(error_2)


