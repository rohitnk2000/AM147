%set x0 to 2
x = 2;
%we want the 3rd root
r = 3;
%we want to find 3 to the r-th root
N = 3;
%set true value before making estimation
x_true = power(3,1/3);
%start loop for iterations from x0 to x3
for i = 0:1:3
    %condition checking to see if the correct value has been reached
   if x^r - N == 0
       break;
   else
       %calculating f(x) and f'(x)
       func_x = (x^r)-N;
       prime_x = r * x^(r-1);
       %setting the next x value
       x = x - func_x/prime_x;
   end
end
%calculating relative error
relative_error = abs(x-x_true)/abs(x_true);
%Printing true value, estimated value, and relative error
disp("True Value:")
disp(x_true)
disp("Estimated Value:")
disp(x)
disp("Relative Error:")
disp(relative_error);
    