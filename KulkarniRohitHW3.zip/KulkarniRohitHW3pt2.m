func_declaration = "@(x)x^3 - x^2 - x - 1";
%calling bisection function with interval (1.5,2) because
%the real solution is 1.8393...
x_real = bisection(1,2,func_declaration,10^(-4),1000);
%displaying this solution
disp("Solution found in given interval:")
disp(x_real)